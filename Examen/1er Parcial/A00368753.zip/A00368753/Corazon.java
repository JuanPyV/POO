public class Corazon{

  private int peso;
  private int pulso;

  public int getPeso() { return peso; }
  public int getPulso(){ return pulso; }

  public Corazon(int peso, int pulso){
    this.peso = peso;
    this.pulso = pulso;
  }
}
