public class ClockException extends Exception {

   // código para hacer esto una excepción con un mensaje
   public ClockException(){
     super("ClockException encountered");
   }

   
}
